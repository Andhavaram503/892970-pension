package com.cts.Dao;

public interface PensionDisbursementDaoInterface {

}