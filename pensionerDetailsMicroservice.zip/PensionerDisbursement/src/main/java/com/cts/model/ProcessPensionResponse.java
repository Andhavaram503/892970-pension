package com.cts.model;

import lombok.Data;

@Data
public class ProcessPensionResponse{
	
	private int status_code;
	
	

}
