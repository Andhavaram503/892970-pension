package com.cognizant.pension;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessPensionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
